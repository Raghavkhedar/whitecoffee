# Handoff: White Coffee — UI Redesign
> **For Claude Code:** This document is a complete implementation guide for a visual redesign of the White Coffee Android app. Read everything here, then open `White Coffee.html` in a browser for the live interactive reference.

---

## Overview

White Coffee is a **field operations mobile app** for Senken Engineering. It manages employee attendance, materials & tools requests/purchases/transfers, work progress reporting, and leave management across three user roles: **Operations**, **Office**, and **Admin**.

This is a **high-fidelity visual redesign** of the existing Android (Kotlin/XML) codebase. The redesign upgrades the UI from a flat light-blue palette to a premium **Midnight Indigo** dark-header system with gradient module icons, glassmorphic card surfaces, and richer typography.

**No Kotlin business logic changes are needed.** All changes are visual: colors, drawables, layouts, and typography.

---

## About the Design Files

The files in this bundle are **HTML/React design prototypes** — they show the exact intended look, feel, animations, and interactions. They are **not** production code.

Your task is to **recreate these designs in the existing Android (Kotlin/XML/Material Components) codebase**, using its established patterns. Match the visual output pixel-perfectly using Android drawables, styles, themes, and layouts.

**Reference file:** Open `White Coffee.html` in a browser. It is a fully interactive prototype you can click through. Use the **Tweaks panel** (bottom-right) to switch between:
- **Role:** `operations` / `office` / `admin` (changes which modules appear)
- **Home layout:** `grid` / `list`

---

## Fidelity

**High-fidelity.** Every color, gradient, radius, shadow, spacing, and typography value below is exact and final. Implement precisely.

---

## Design System

### Color Tokens

| Token name | Hex value | Usage |
|---|---|---|
| `midnight` | `#05091A` | Header darkest gradient stop, status bar |
| `deep` | `#0D1836` | Header mid gradient stop |
| `navy` | `#1A2F72` | Header light gradient stop |
| `primary_blue` | `#3B82F6` | Buttons, links, focused inputs, accent |
| `violet` | `#7C3AED` | Secondary accent |
| `background` | `#ECEFFE` | All screen backgrounds (slight lavender tint) |
| `surface` | `#FFFFFF` | Card surfaces |
| `text_primary` | `#050B20` | Headings, bold labels |
| `text_secondary` | `#3A4470` | Body text |
| `text_hint` | `#8591BD` | Placeholders, captions, section labels |
| `header_text_sub` | `#A0BEFF` | Header subtitle / greeting text |
| `accent_light` | `#EEF2FF` | Light accent fills, chips |
| `border` | `#E0E4F8` | Card strokes, dividers |
| `status_pending` | `#D97706` / bg `#FEF3C7` / text `#92400E` | Pending badges |
| `status_approved` | `#059669` / bg `#D1FAE5` / text `#065F46` | Approved badges |
| `status_rejected` | `#E11D48` / bg `#FFE4E6` / text `#9F1239` | Rejected / danger badges |
| `success` | `#059669` | Success states |
| `warning` | `#D97706` | Warning states |
| `danger` | `#E11D48` | Danger / check-out actions |

### Typography

Two fonts used throughout:

| Role | Font | Weights | Usage |
|---|---|---|---|
| **Heading** | Space Grotesk | 600, 700 | Screen titles, card titles, button text, section labels, module names, date numbers |
| **Body** | DM Sans | 400, 500 | Body copy, captions, subtitles, input text, hints, tab labels |

**Scale:**
- Screen title (header): 19–22sp, bold, `letterSpacing="-0.02"` to `"-0.03"`
- Card title: 13–14sp, semibold
- Body: 13–14sp, regular
- Caption / hint: 11–12sp, regular
- Section label: 11sp, bold, ALL CAPS, `letterSpacing="0.10"`
- Greeting: 12sp, regular, `header_text_sub` color

### Spacing & Radii

| Element | Value |
|---|---|
| Card corner radius | 20dp |
| Module icon corner radius | 13dp |
| Button corner radius | 14dp |
| Input corner radius | 12dp |
| Status badge corner radius | 20dp (pill) |
| Role badge corner radius | 20dp (pill) |
| Back button size | 38×38dp |
| Back button corner radius | 11dp |
| Screen horizontal padding | 14–15dp |
| Card inner padding | 14–16dp |
| Gap between cards | 9–10dp |

### Shadows / Elevation

| Element | Elevation |
|---|---|
| Cards | 2dp (max 4dp) |
| Primary button | 0dp (shadow via box-shadow on Android: not applicable; use `stateListAnimator=@null`) |
| FAB | 6dp |
| Modal sheet | High (use `elevation` on BottomSheetDialog) |

---

## Module Icon Gradients

Each module has a unique gradient for its 44×44dp icon container (corner radius 13dp):

| Module | Start color | End color | Glow shadow color |
|---|---|---|---|
| Attendance | `#1E3A8A` | `#3B82F6` | `rgba(59,130,246,0.30)` |
| M&T Request | `#9A3412` | `#F97316` | `rgba(249,115,22,0.30)` |
| M&T Buy | `#064E3B` | `#10B981` | `rgba(16,185,129,0.30)` |
| Material Transfer | `#4C1D95` | `#8B5CF6` | `rgba(139,92,246,0.30)` |
| Tool Transfer | `#164E63` | `#06B6D4` | `rgba(6,182,212,0.30)` |
| Work Progress | `#78350F` | `#FBBF24` | `rgba(251,191,36,0.28)` |
| Leave | `#881337` | `#F43F5E` | `rgba(244,63,94,0.30)` |
| Leave Approvals | `#064E3B` | `#34D399` | `rgba(52,211,153,0.28)` |

Gradient angle: 135° (top-left → bottom-right). Icon is white (stroke/fill) on top.

---

## Header System

All screen headers share the same style:

- **Background:** Linear gradient 150° from `#05091A` → `#0D1836` → `#1A2F72`
- **Status bar color:** `#05091A`, light icons (white)
- **Padding top:** 52–72dp (to clear status bar), 16–20dp horizontal, 18–22dp bottom
- **Back button:** 38×38dp rounded rect (11dp radius), background `rgba(255,255,255,0.09)`, border `rgba(255,255,255,0.14)`, white chevron icon (`←`)
- **Title:** Space Grotesk 19sp bold, white, `letterSpacing="-0.02"`
- **Subtitle:** DM Sans 11sp regular, `#A0BEFF`

**Home header** additionally has:
- Greeting text (DM Sans 12sp, `#A0BEFF`): "Good morning/afternoon/evening,"
- User name (Space Grotesk 22sp bold, white, `letterSpacing="-0.03"`)
- Role badge: pill shape, background `rgba(255,255,255,0.09)`, border `rgba(255,255,255,0.14)`, 6dp colored dot + DM Sans 11sp 500 white text
  - Operations dot: `#60A5FA`
  - Office dot: `#A78BFA`
  - Admin dot: `#34D399`
- Top-right: notification bell button (same style as back button, 40×40dp, 12dp radius) with red badge for unread count, and a "Logout" text button (DM Sans 11sp, border `rgba(255,255,255,0.18)`, 10dp radius)

---

## Screens

### 1. Login Screen

**Layout:** Full-screen `ScrollView`. Dark hero at top (same header gradient), white card overlapping it with negative margin (-24dp).

**Hero section:**
- Padding: 72dp top, 28dp horizontal, 60dp bottom
- Center-aligned content
- Logo: 82×82dp rounded rect (26dp radius), `rgba(255,255,255,0.14)` background, white border, "WC" in Space Grotesk 28sp bold white
- App name: Space Grotesk 28sp bold white, `letterSpacing="-0.035"`
- Subtitle: DM Sans 12sp `#A0BEFF`, centered, "Senken Engineering\nField Operations Platform"

**Form card:**
- `MaterialCardView` 20dp radius, margin 18dp horizontal, overlaps hero by 24dp
- Inner padding: 22dp
- "Welcome back" heading: Space Grotesk 20sp bold, `#050B20`
- Subtitle: DM Sans 12sp `#8591BD`
- Email + Password `TextInputLayout` (outlined, 12dp radius, stroke `#E0E4F8`, focused stroke `#3B82F6`)
- Error text: DM Sans 11sp `#E11D48`
- Primary button: "Sign In →"
- Loading: `LinearProgressIndicator`

**Footer:** "Senken Engineering © 2025", DM Sans 11sp `#8591BD`, centered

---

### 2. Home Screen

**Modules shown per role:**

| Module | Operations | Office | Admin |
|---|---|---|---|
| Attendance | ✓ | ✓ | ✓ |
| M&T Request | ✓ | — | — |
| M&T Buy | ✓ | ✓ | ✓ |
| Material Transfer | ✓ | ✓ | ✓ |
| Tool Transfer | ✓ | ✓ | ✓ |
| Work Progress | ✓ | — | — |
| Leave | ✓ | ✓ | ✓ |
| Leave Approvals | — | — | ✓ |

**Attendance tap behavior:**
- Operations role → goes to `AttendanceScreen` (home/site/market flow)
- Office / Admin role → goes to `OfficeAttScreen` (simple check-in/out)

**Today summary card** (below header, above modules):
- Glass card (20dp radius)
- Left: day name (DM Sans 11sp hint), date number (Space Grotesk 28sp bold, `letterSpacing="-0.04"`), month+year (DM Sans 12sp secondary)
- Divider: 1dp × 44dp `#E0E4F8`
- Right: "Attendance" label (DM Sans 10sp hint), status pill: `rgba(244,63,94,0.08)` bg, animated red dot (pulse), "Not checked in" Space Grotesk 11sp bold `#F43F5E`

**Section label:** "Quick Actions" — Space Grotesk 10sp bold ALL CAPS `#8591BD` `letterSpacing=0.10`

**Module grid:** 2-column grid OR list, togglable. Gap: 9dp.

**Grid card:** 20dp radius glass card, 16dp padding, min-height 110dp. Icon container 44×44dp gradient rounded rect at top, title Space Grotesk 12sp 600, sub DM Sans 10sp hint.

**List card:** Same glass card, horizontal layout. Icon on left, title + sub in middle, chevron on right (28×28dp, `#ECEFFE` bg, `#8591BD` chevron).

**Staggered entrance animation:** Cards fade up sequentially (50ms delay between each).

---

### 3. Attendance Screen (Operations)

State machine with 5 states: `no_record` → `home_in` → `site_in` / `market_in` → `day_complete`

**Status card:** Glass card, current status label + animated dot (pulsing when active)

| State | Dot color | Label |
|---|---|---|
| no_record | `#9CA3AF` | "Not Checked In" |
| home_in | `#16A34A` | "Working from Home" |
| site_in | `#3B82F6` | "At Site — [name]" |
| market_in | `#EA580C` | "At Market — [name]" |
| day_complete | `#059669` | "Day Complete" |

**Action buttons by state:**
- `no_record`: Primary "Check In from Home"
- `home_in`: Primary "Check In at Site", Outline "Go to Market", Outline danger "Check Out from Home"
- `site_in`: Primary "Go to Market", Outline danger "Leave Site"
- `market_in`: Outline danger "Leave Market"

**Inline dialog** (slides down below buttons): Glass card with blue border, title "📍 Site Details" or "📍 Market Details", `InputField` components, Confirm + Cancel buttons side by side.

**Today's Log:** Timeline with vertical line, colored dots per event type, type label + place + time.

**Day Complete state:** Centered success card with green checkmark circle, "Day Complete!" heading, "Great work today" message.

---

### 4. Office Attendance Screen

Simpler flow: single check-in / check-out toggle. Supports multiple cycles per day.

**Center card:**
- 60×60dp circle with clock icon, green when checked in, blue when not
- Status text + sub-label
- Location `InputField` shown only when NOT checked in
- Primary "Check In →" or Outline danger "Check Out" button

**Today's Log:** Same timeline component as above (uses `office_in` / `office_out` event types).

---

### 5. Notifications Screen

**Header:** "Notifications", subtitle shows unread count or "All caught up"

**"Mark all as read" button:** DM Sans 11sp 500 `#3B82F6`, text button, top-right, only visible when unread > 0

**Notification card:** Glass card 14dp radius, left border 3dp colored when unread (hidden when read), slightly more opaque when unread.

| Type | Left border color |
|---|---|
| urgent | `#F43F5E` |
| leave_update | `#3B82F6` |
| work_reminder | `#F59E0B` |
| general | `#7C3AED` |

Card content: title (Space Grotesk 12sp, bold if unread), body (DM Sans 11sp hint), timestamp (DM Sans 9sp hint), unread dot (7dp circle, same color as border).

---

### 6. Leave Screen

**Header:** "My Leaves", subtitle shows pending count

**Leave cards:** Glass card 16dp radius. Top row: leave type (Space Grotesk 13sp bold) + date range (DM Sans 11sp hint) + `StatusBadge`. Bottom row: reason text + days chip (`#EEF2FF` bg, `#3B82F6` text, Space Grotesk 11sp bold).

**FAB:** "Apply Leave" — `ExtendedFloatingActionButton`, gradient `#1A3B6E → #2563EB`, 16dp radius, white "+" icon + label, shadow `rgba(37,99,235,0.42)`

**Apply Leave bottom sheet** (slides up from bottom):
- Handle: 36×4dp, `#E2E8F0`, 99dp radius, centered
- Title "Apply Leave" + ✕ close button (30×30dp, `#F1F5F9` bg, 8dp radius)
- **Leave type selector:** horizontal chip row — `Casual Leave / Sick Leave / Annual Leave / Emergency Leave / Unpaid Leave`. Selected: `#EEF2FF` bg, `#3B82F6` border + text. Unselected: white bg, `#E0E4F8` border.
- **Date range:** 2-column grid, native date inputs, 12dp radius border
- **Duration badge:** shown when valid date range — glass card, calendar icon, "X day(s) of leave"
- **Reason:** multiline `TextInputEditText`, 3 rows
- Primary "Submit Application →" button (disabled until all fields filled)

---

### 7. M&T Buy Screen

**Sections (glass cards):**
1. **Site Details:** Site Name + Site ID (optional) fields
2. **Items list:** Expandable. Each item: name, qty, unit, ₹/unit. "+ Add Item" dashed button at bottom.
3. **Grand Total:** shown when total > 0 — "₹XX,XXX" Space Grotesk 15sp bold `#3B82F6`
4. **Photos:** Grid of photo thumbnails + "Add" dashed square button (60×60dp, 10dp radius)

**Success state:** Full-screen centered — green circle with checkmark, "Submitted!", "pending approval" subtitle, back button.

---

### 8. M&T Request Screen

Same layout as M&T Buy, but instead of price column: **Notes** column. Adds **Urgency selector** in site details section:
- Segments: `normal / urgent / critical`
- Selected: `#EEF2FF` bg, `#3B82F6` border + text. Unselected: `rgba(255,255,255,0.6)` bg.

---

### 9. Material Transfer / Tool Transfer Screens

Shared `TransferScreen` component, `type` prop = `"material"` or `"tool"`.

**Sections:**
1. **Transfer Details:** From / To (2-column grid) + Transferred By / Received By (2-column grid)
2. **Items:** Same add-item list. Columns: Qty, Unit, Condition

---

### 10. Work Progress Screen

**Sections:**
1. **Site Details:** Site Name, Site ID, Hours Worked + Workers On Site (2-column grid)
2. **Overall Completion:** Horizontal progress bar (8dp height, 99dp radius) + percentage label (Space Grotesk 14sp bold). Color: `#E11D48` < 30%, `#D97706` < 70%, `#16A34A` ≥ 70%. Controlled by a native `SeekBar` below.
3. **Work Description:** Multiline `TextInputEditText`, 4 rows
4. **Photos**

---

## Interactions & Animations

| Interaction | Spec |
|---|---|
| Screen transition (forward) | Slide in from right: `translateX(36px → 0)`, 300ms, `cubic-bezier(0.4, 0, 0.2, 1)` |
| Screen transition (back) | Slide in from left: `translateX(-36px → 0)`, same timing |
| Card entrance stagger | `fadeUp` (translateY 12px → 0, opacity 0 → 1), 320ms, 50ms delay per item |
| Button press | `scale(0.975)` on press, `scale(1)` on release, 100ms ease |
| Module grid card press | `scale(0.96)` |
| Bottom sheet | Slides up from bottom: `translateY(100% → 0)`, 280ms `cubic-bezier(0.4,0,0.2,1)` |
| Inline dialog | Slides down: `opacity 0, translateY(-12px) → opacity 1, translateY(0)`, 220ms |
| Loading spinner | Circular border spinner, 700ms linear infinite |
| Attendance status dot | Pulse ring: scale 1→1.07, opacity 0.55→0.18, 2s ease-in-out infinite |
| Login logo | Float: translateY 0 → -7px → 0, 3.5s ease-in-out infinite |
| Login pulse rings | Two concentric rings, 3.2s ease-in-out, 0.8s offset between them |

---

## State Management (per screen)

| Screen | Key state variables |
|---|---|
| Login | `email`, `pass`, `loading`, `error` |
| Home | `role` (from user session), `layout` (grid/list, persisted) |
| Attendance (ops) | `state` (enum), `events` (list), `dialog` (null/site/market), `siteName`, `siteId`, `mktName`, `loading` |
| Office Attendance | `checkedIn`, `location`, `events`, `loading` |
| Notifications | `notifications` (list with `read` flag) |
| Leave | `leaves` (list), `showForm` |
| M&T Buy | `siteName`, `siteId`, `items` (list), `photos` (count), `loading`, `done` |
| M&T Request | Same as Buy + `urgency` (normal/urgent/critical) |
| Transfer | `from`, `to`, `byWho`, `recvBy`, `items`, `photos`, `loading`, `done` |
| Work Progress | `siteName`, `siteId`, `hours`, `workers`, `description`, `progress` (0–100), `photos`, `loading`, `done` |

---

## Demo / Placeholder Data

The prototype uses this data — replace with real API calls:

**Notifications:**
- "Leave Approved" — leave_update, unread, 2h ago
- "Work Progress Reminder" — work_reminder, unread, 5h ago
- "System Maintenance" — general, read, Yesterday
- "Urgent: Safety Alert" — urgent, read, 2d ago

**Leave requests:**
- Casual Leave, 20 Jun → 20 Jun, 1 day, approved, "Personal errand"
- Sick Leave, 14 Jun → 15 Jun, 2 days, pending, "Fever and flu"
- Annual Leave, 28 May → 1 Jun, 5 days, rejected, "Family vacation"

**User names per role:**
- Operations: "Arjun Sharma"
- Office: "Priya Mehta"
- Admin: "Rajesh Kumar"

---

## Files in This Bundle

| File | Purpose |
|---|---|
| `README.md` | This document — primary implementation guide |
| `White Coffee.html` | Interactive hi-fi prototype — open in browser |
| `wc-components.jsx` | Design system: color tokens, shared UI components |
| `wc-screens.jsx` | All 10 screen implementations |
| `WhiteCoffee UI Redesign Handoff.md` | Android XML/Kotlin resource changes (colors.xml, themes.xml, all drawables, layout XML) |

**Start with `WhiteCoffee UI Redesign Handoff.md`** — it has ready-to-paste Android XML for every resource file. Use `White Coffee.html` as the live visual reference to verify your implementation.

---

## Verification Checklist

After implementing, verify against `White Coffee.html`:

- [ ] Background is `#ECEFFE` (lavender tint, not white or grey)
- [ ] All headers: deep midnight-to-indigo gradient (NOT light blue)
- [ ] Status bar: `#05091A`, white icons
- [ ] Back buttons: frosted glass pill, NOT plain icon
- [ ] Module icons: distinct colored gradients, white icons on top, 13dp radius
- [ ] Today card visible on Home screen above module grid
- [ ] Primary button: dark→blue gradient, NOT flat blue, 0dp elevation
- [ ] Cards: 20dp corner radius, `#E0E4F8` border
- [ ] Status badges: Pending=amber, Approved=green, Rejected=rose
- [ ] Fonts: Space Grotesk for headings/buttons, DM Sans for body/inputs
- [ ] Leave FAB: gradient, 16dp radius
- [ ] Bottom sheet slides up with handle bar
- [ ] Attendance timeline shows correct dot colors per event type
- [ ] Role badge in home header shows correct colored dot
